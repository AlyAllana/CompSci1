
/**
 * Write a description of class Fruit here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fruit{
        public static void main (String[]args) {
            int Apples = 35;
            int Oranges = 22;
            int Peaches = 18;
            int Grapes = 10;
            int Bananas = 8;
            int Pineapples = 5;
            
            System.out.println("            Totals");
            System.out.println("-------------------------------");
            System.out.println("Apples" + " = " + Apples);
            System.out.println("Oranges" + " = " + Oranges);
            System.out.println("Peaches" + " = " + Peaches);
            System.out.println("Grapes" + " = " + Grapes );
            System.out.println("Bananas" + " = " + Bananas);
            System.out.println("Pineapples" + " = " + Pineapples);

    
        }   
}