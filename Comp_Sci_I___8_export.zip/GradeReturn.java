import java.util.Scanner;
/**
 * Write a description of class GradeReturn here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GradeReturn 
{
    public int numberGrade (int input)
    {
        Scanner fromKey = new Scanner(System.in);
        System.out.print("Enter number grade: ");
        input =  fromKey.nextInt();
        if (input >= 90)
        {
        System.out.println("You earned a: A");
 
        }
 
        else if (input >= 80)
        {
        System.out.println("You earned a: B");
        }
 
        else if (input >= 75)
        {
        System.out.println("You earned a: C");
 
        }
 
        else if (input >= 70)
        {
        System.out.println("You earned a: D");
 
        }
 
        else if (input < 70)
        {
        System.out.println("You earned a: F");
 
        }
        return input;
    }
}
 
 
 