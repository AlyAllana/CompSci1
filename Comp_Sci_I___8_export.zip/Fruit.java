
/**
 * Write a description of class Fruit here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fruit{
        public static void main (String[]args) {
            System.out.println("            Totals");
            System.out.println("-------------------------------");
            System.out.println("Apples = " + 35);
            System.out.println("Oranges = " + 22);
            System.out.println("Peaches = " + 18);
            System.out.println("Grapes = " + 10);
            System.out.println("Bananas = " + 8);
            System.out.println("Pineapples = " + 5);

    
        }   
}