import java.util.Scanner;
public class OddEvenString {
    public static void main (String[]args) { 
        Scanner fromKey = new Scanner (System.in);
        String word = "";
        int len = 0;
        int evenoddCheck;
        
        System.out.print("Enter a word:: ");
        word = fromKey.next();
        len = word.length();
        
        evenoddCheck = len % 2;
        if (evenoddCheck == 0) 
        {System.out.println(word + " is even. ");
        }
        
        if (evenoddCheck == 1)
        {System.out.println(word + " is odd. ");
        }

    }
}
