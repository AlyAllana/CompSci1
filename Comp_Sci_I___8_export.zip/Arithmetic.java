
/**
 * Write a description of class Arithmetic here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Arithmetic{
public static void main (String[]args){
    //Numerical Variables
    int num1 = 25;
    int num2 = 6;
    
    //sum
    int sum = 0;
    sum = num1 + num2;
    
    //difference
    int difference = 0;
    difference = num1 - num2; 
    
    //product 
    int product = 0;
    product = num1 * num2;
    
    //quotient 
    int quotient = 0;
    quotient = num1/num2;
    
    //remainder
    int remainder = 0;
    remainder = num1%num2;
    
    
    System.out.println("         Arithmetic      ");
    System.out.println("============================");
    System.out.println(num1 + " + " + num2 + " = " + sum);
    System.out.println(num1 + " - " + num2 + " = " + difference);
    System.out.println(num1 + " * " + num2 + " = " + product);
    System.out.println(num1 + " / " + num2 + " = " + quotient);
    System.out.println(num1 + " % " + num2 + " = " + remainder);
    
    
    


  
    }
}
