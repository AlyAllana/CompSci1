
/**
 * Write a description of class ASCIIArt here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ASCIIArt
{
    public static void main (String[] args)
    {
        System.out.print("\n");
        System.out.print("\n          __     --");
        System.out.print("\n         /  \\~~~/  \\");
        System.out.print("\n   ,----(     ..    )");
        System.out.print("\n  /      \\__     __/");
        System.out.print("\n /|         (\\   |(");
        System.out.print("\n^ \\   /___\\  /\\ |");
        System.out.print("\n   |__|    |__|-\"");
        System.out.print("\n");
    } 
}


