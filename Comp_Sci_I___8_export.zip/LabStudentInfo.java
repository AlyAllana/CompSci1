
/**
 * Write a description of class LabStudentInfo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LabStudentInfo {
    
public static void main(String[] args) {

     System.out.println ("Student Information");
     
     System.out.println ("------------------------------ ");
     
     System.out.println ("John Wayne");
     
     System.out.println ("4005 Main Street");
     
     System.out.println ("Denton, TX 76201");
     
     System.out.println("940-382-5600");
     
     System.out.println ("Junior");
     
     System.out.println ("         ");
     
     System.out.println ("Parent or guardian information");
     
     System.out.println ("------------------------------ ");
     
     System.out.println ("Martha Wayne");
     
     System.out.println ("4005 Main Street");
     
     System.out.println ("Denton, TX 76201");
     
     System.out.println ("940-382-5000");
     
     System.out.println ("940-387-1515");
     
     System.out.println ("Denton ISD");
     
     
     
     
     
    

    
        }
    
}
