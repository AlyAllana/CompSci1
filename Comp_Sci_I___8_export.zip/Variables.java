/**
 * Write a description of class Variables here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Variables{
    public static void main (String [] args){
        //integer types
        byte byteOne = 127; //8bit
        short shortOne = -32123; //16bit
        int intOne = 90877;  //32 bit
        long longOne = 999999999L; //64 bit
        
        //real types 
        float floatOne = 38.5678f; //32 bit
        double doubleOne = 923.234; //64 bit
        
        //other integer types 
        char charOne = 'A'; //16 bit 
        
        //other types 
        boolean booleanOne = true; 
        String stringOne = "hello world";
        
        System.out.println("/////////////////////////////////");
        System.out.println("*Jim Bob                08/18/08*");
        System.out.println("*                               *");
        System.out.println("*         integer types         *");
        System.out.println("*                               *");
        System.out.println("*8 bit - byteOne = "+byteOne+"          *");
        System.out.println("*16 bit - shortOne = "+shortOne+"     *");
        System.out.println("*32 bit - intOne = "+intOne+"        *");
        System.out.println("*64 bit - longOne = "+longOne+"   *");
        System.out.println("*                               *");
        System.out.println("*         real types            *");
        System.out.println("*                               *");
        System.out.println("*32 bit - floatOne = "+floatOne+"    *");
        System.out.println("*64 bit - doubleOne = "+doubleOne+"   *");
        System.out.println("*                               *");
        System.out.println("*      other integer types      *");
        System.out.println("*                               *");
        System.out.println("*16 bit - charOne = "+charOne+"           *");
        System.out.println("*                               *");
        System.out.println("*         other types           *");
        System.out.println("*                               *");
        System.out.println("*booleanOne = "+booleanOne+"              *");
        System.out.println("*stringOne = "+stringOne+"        *");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        
        
        
        
        
        
        
        
        
        
        
    
    

    
    
    
    
    }
}
