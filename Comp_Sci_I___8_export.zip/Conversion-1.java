
/**
 * Conversion Lab 
 *
 * @author ()
 * @version ()
 */
public class Conversion
{
    public static void main (String[]args){
        
        System.out.println("          Units and Conversion Factors");
        System.out.println("----------------------------------------------");
        
        double Inch = 2.54;
        double Yard = 0.9144;
        double Mile = 1.609;
        double Centimeter = 0.3937;
        double Meter = 1.094;
        double Kilometer = 0.6214;
        double LightYear = 9.464E12;
         
        
        System.out.println("1 inch" + " = " + Inch + " centimeters");
        System.out.println("1 yard" + " = " + Yard + " meters");
        System.out.println("1 mile" + " = " + Mile + " kilometers");
        System.out.println("1 centimeter" + " = " + Centimeter + " inches");
        System.out.println("1 meter" + " = " + Meter + " yards"); 
        System.out.println("1 kilometer" + " = " + Kilometer + " miles");
        System.out.println("1 light year" + " = " + LightYear + " kilometers");
        

    
        
        
        
        
        
        
    

       


    }           
}    
