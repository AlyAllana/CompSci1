
/**
 * Write a description of class Fruit here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fruit{
        public static void main (String[]args) {
            int apples = 35;
            int oranges = 22;
            int peaches = 18;
            int grapes = 10;
            int bananas = 8;
            int pineapples = 5;
            
            System.out.println("            Totals");
            System.out.println("-------------------------------");
            System.out.println("Apples" + " = " + apples);
            System.out.println("Oranges" + " = " + oranges);
            System.out.println("Peaches" + " = " + peaches);
            System.out.println("Grapes" + " = " + grapes );
            System.out.println("Bananas" + " = " + bananas);
            System.out.println("Pineapples" + " = " + pineapples);

    
        }   
}