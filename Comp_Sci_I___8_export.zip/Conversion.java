
/**
 * Conversion Lab 
 *
 * @author ()
 * @version ()
 */
public class Conversion
{
    public static void main (String[]args){
        System.out.println("          Units and Conversion Factors");
        System.out.println("----------------------------------------------");
        
        double Inch = 2.54;
        System.out.println("1 inch" + " = " + Inch + " centimeters");
        
        double Yard = 0.9144;
        System.out.println("1 yard" + " = " + Yard + " meters");
        
        double Mile = 1.609;
        System.out.println("1 mile" + " = " + Mile + " kilometers");
        
        double Centimeter = 0.3937;
        System.out.println("1 centimeter" + " = " + Centimeter + " inches"); 
        
        double Meter = 1.094;
        System.out.println("1 meter" + " = " + Meter + " yards"); 
        
        double Kilometer = 0.6214;
        System.out.println("1 kilometer" + " = " + Kilometer + " miles");
        
        double LightYear = 9.464E12;
        System.out.println("1 light year" + " = " + LightYear + " kilometers"); 
        
        

        
        
        
        
        
        
        
    

       


    }           
}    
